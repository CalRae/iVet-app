sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.jigsawCloudTechnologies.iVet.controller.AccountUpgrade", {
		visitSecondScreen: function () {
				this.getOwnerComponent().getRouter().navTo("secondPage");
			}

	});

});