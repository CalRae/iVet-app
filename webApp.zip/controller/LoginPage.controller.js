sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.jigsawCloudTechnologies.iVet.controller.LoginPage", {
		onLogin: function () {
				this.getOwnerComponent().getRouter().navTo("homePage");
			},
		onSign: function () {
			this.getOwnerComponent().getRouter().navTo("register");
		},
		resetPassord: function () {
			this.getOwnerComponent().getRouter().navTo("resetPassword");
		}

	});

});