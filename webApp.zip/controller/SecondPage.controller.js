sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.jigsawCloudTechnologies.iVet.controller.SecondPage", {
		goToLogin: function () {
				this.getOwnerComponent().getRouter().navTo("loginPage");
			}

	});

});