sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.jigsawCloudTechnologies.iVet.controller.Register", {
		onRegister: function () {
			var termsAndConditions = this.getView().byId("termsAndConditions");
			var privacyAndConsent = this.getView().byId("privacyAndConsent");
			if(termsAndConditions.getSelected() && privacyAndConsent.getSelected()){
				this.getOwnerComponent().getRouter().navTo("homePage");
			}
		
		}

	});

});